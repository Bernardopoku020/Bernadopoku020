const express = require("express");
const bcrypt = require("bcryptjs");
const db = require("../database/database");
const router = express.Router();

function publicCustomer(customer) {
    return { id: customer.id, first_name: customer.first_name, last_name: customer.last_name, email: customer.email, phone: customer.phone };
}

router.post("/register", async (req, res) => {
    const { first_name, last_name, email, phone, password } = req.body;
    if (!first_name || !last_name || !phone || !password) return res.status(400).json({ success: false, message: "First name, last name, phone and password are required." });
    if (password.length < 8) return res.status(400).json({ success: false, message: "Password must be at least 8 characters." });
    try {
        const normalizedEmail = email ? email.trim().toLowerCase() : null;
        if (db.prepare("SELECT id FROM customers WHERE phone = ? OR (email IS NOT NULL AND email = ?)").get(phone.trim(), normalizedEmail || "")) {
            return res.status(409).json({ success: false, message: "An account with that phone or email already exists." });
        }
        const hash = await bcrypt.hash(password, 12);
        const result = db.prepare("INSERT INTO customers (first_name, last_name, email, phone, password) VALUES (?, ?, ?, ?, ?)").run(first_name.trim(), last_name.trim(), normalizedEmail, phone.trim(), hash);
        const customer = db.prepare("SELECT * FROM customers WHERE id = ?").get(result.lastInsertRowid);
        req.session.customer = publicCustomer(customer);
        res.status(201).json({ success: true, user: req.session.customer });
    } catch (error) {
        console.error("Customer registration error:", error);
        res.status(500).json({ success: false, message: "Could not create your account." });
    }
});

router.post("/login", async (req, res) => {
    const { identifier, password } = req.body;
    if (!identifier || !password) return res.status(400).json({ success: false, message: "Email or phone and password are required." });
    try {
        const customer = db.prepare("SELECT * FROM customers WHERE email = ? OR phone = ?").get(identifier.trim().toLowerCase(), identifier.trim());
        if (!customer || !(await bcrypt.compare(password, customer.password))) return res.status(401).json({ success: false, message: "Those login details are not correct." });
        req.session.customer = publicCustomer(customer);
        res.json({ success: true, user: req.session.customer });
    } catch (error) {
        console.error("Customer login error:", error);
        res.status(500).json({ success: false, message: "Could not log you in." });
    }
});

router.get("/me", (req, res) => {
    res.json({ success: true, user: req.session.customer || null });
});

module.exports = router;
