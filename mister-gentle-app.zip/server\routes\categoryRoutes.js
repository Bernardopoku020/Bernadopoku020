const express = require("express");
const router = express.Router();

const db = require("../../database/database");

// ========================================
// GET ALL CATEGORIES
// ========================================

router.get("/", (req, res) => {
    try {
        const categories = db.prepare(`
            SELECT
                id,
                name,
                description,
                image,
                sort_order,
                is_active,
                created_at
            FROM categories
            WHERE is_active = 1
            ORDER BY sort_order ASC, name ASC
        `).all();

        res.json({
            success: true,
            count: categories.length,
            categories
        });

    } catch (error) {
        console.error("Get categories error:", error);

        res.status(500).json({
            success: false,
            message: "Failed to load categories."
        });
    }
});

// ========================================
// GET SINGLE CATEGORY
// ========================================

router.get("/:id", (req, res) => {
    try {
        const category = db.prepare(`
            SELECT
                id,
                name,
                description,
                image,
                sort_order,
                is_active,
                created_at
            FROM categories
            WHERE id = ?
        `).get(req.params.id);

        if (!category) {
            return res.status(404).json({
                success: false,
                message: "Category not found."
            });
        }

        res.json({
            success: true,
            category
        });

    } catch (error) {
        console.error("Get category error:", error);

        res.status(500).json({
            success: false,
            message: "Failed to load category."
        });
    }
});

// ========================================
// CREATE CATEGORY
// ========================================

router.post("/", (req, res) => {
    try {
        const {
            name,
            description,
            image,
            sort_order
        } = req.body;

        if (!name || !name.trim()) {
            return res.status(400).json({
                success: false,
                message: "Category name is required."
            });
        }

        const existing = db.prepare(`
            SELECT id
            FROM categories
            WHERE name = ?
        `).get(name.trim());

        if (existing) {
            return res.status(409).json({
                success: false,
                message: "A category with this name already exists."
            });
        }

        const result = db.prepare(`
            INSERT INTO categories
            (
                name,
                description,
                image,
                sort_order
            )
            VALUES (?, ?, ?, ?)
        `).run(
            name.trim(),
            description || null,
            image || null,
            Number(sort_order) || 0
        );

        const category = db.prepare(`
            SELECT *
            FROM categories
            WHERE id = ?
        `).get(result.lastInsertRowid);

        res.status(201).json({
            success: true,
            message: "Category created successfully.",
            category
        });

    } catch (error) {
        console.error("Create category error:", error);

        res.status(500).json({
            success: false,
            message: "Failed to create category."
        });
    }
});

// ========================================
// UPDATE CATEGORY
// ========================================

router.put("/:id", (req, res) => {
    try {
        const {
            name,
            description,
            image,
            sort_order,
            is_active
        } = req.body;

        const category = db.prepare(`
            SELECT *
            FROM categories
            WHERE id = ?
        `).get(req.params.id);

        if (!category) {
            return res.status(404).json({
                success: false,
                message: "Category not found."
            });
        }

        db.prepare(`
            UPDATE categories
            SET
                name = ?,
                description = ?,
                image = ?,
                sort_order = ?,
                is_active = ?
            WHERE id = ?
        `).run(
            name !== undefined ? name.trim() : category.name,
            description !== undefined ? description : category.description,
            image !== undefined ? image : category.image,
            sort_order !== undefined
                ? Number(sort_order)
                : category.sort_order,
            is_active !== undefined
                ? Number(is_active)
                : category.is_active,
            req.params.id
        );

        const updatedCategory = db.prepare(`
            SELECT *
            FROM categories
            WHERE id = ?
        `).get(req.params.id);

        res.json({
            success: true,
            message: "Category updated successfully.",
            category: updatedCategory
        });

    } catch (error) {
        console.error("Update category error:", error);

        res.status(500).json({
            success: false,
            message: "Failed to update category."
        });
    }
});

// ========================================
// DELETE CATEGORY
// ========================================

router.delete("/:id", (req, res) => {
    try {
        const category = db.prepare(`
            SELECT *
            FROM categories
            WHERE id = ?
        `).get(req.params.id);

        if (!category) {
            return res.status(404).json({
                success: false,
                message: "Category not found."
            });
        }

        const productCount = db.prepare(`
            SELECT COUNT(*) AS count
            FROM products
            WHERE category_id = ?
        `).get(req.params.id);

        if (productCount.count > 0) {
            return res.status(409).json({
                success: false,
                message: "This category contains products. Remove or move the products before deleting the category."
            });
        }

        db.prepare(`
            DELETE FROM categories
            WHERE id = ?
        `).run(req.params.id);

        res.json({
            success: true,
            message: "Category deleted successfully."
        });

    } catch (error) {
        console.error("Delete category error:", error);

        res.status(500).json({
            success: false,
            message: "Failed to delete category."
        });
    }
});

module.exports = router;