window.MisterGentleMenu = { products: [
  {id:1,category:"sauce",name:"Vegetable Sauce",description:"Fresh mixed vegetables in our house sauce",price:40},
  {id:2,category:"sauce",name:"Beef Sauce",description:"Tender beef with a rich, savoury sauce",price:40},
  {id:3,category:"sauce",name:"Chicken Sauce",description:"Seasoned chicken in our house sauce",price:40},
  {id:4,category:"main",name:"Fried Rice with Chicken",description:"Choose serving and chicken style",variants:[["GH₵40",40],["GH₵50",50]],choices:["Grilled Chicken","Fried Chicken"]},
  {id:5,category:"main",name:"Jollof Rice with Chicken",description:"Choose serving and chicken style",variants:[["GH₵40",40],["GH₵50",50]],choices:["Grilled Chicken","Fried Chicken"]},
  {id:6,category:"main",name:"Assorted Fried Rice",description:"A generous serving of assorted fried rice",price:50},
  {id:7,category:"main",name:"Assorted Jollof",description:"A generous serving of assorted jollof",price:50},
  {id:8,category:"main",name:"Vegetable Fried Rice",description:"Colourful vegetables tossed with fried rice",price:40},
  {id:9,category:"main",name:"Plain Rice with Sauce",description:"Steamed rice served with your choice of sauce",price:70},
  {id:10,category:"main",name:"Sausage Fried Rice",description:"Choose your serving price",variants:[["GH₵40",40],["GH₵50",50]]},
  {id:11,category:"main",name:"Beef Fried Rice",description:"Choose your serving price",variants:[["GH₵40",40],["GH₵50",50]]},
  {id:12,category:"main",name:"Chicken Fried Rice",description:"Choose your serving price",variants:[["GH₵40",40],["GH₵50",50]]},
  {id:13,category:"salad",name:"Tuna Salad",description:"Fresh salad with delicious tuna",price:30},
  {id:14,category:"salad",name:"Chicken Salad",description:"Crisp greens with tender chicken",price:30},
  {id:15,category:"salad",name:"Ghana Mix Salad",description:"A fresh local favourite",price:30},
  {id:16,category:"noodles",name:"Beef Noodles",description:"Stir-fried noodles with seasoned beef",variants:[["GH₵40",40],["GH₵50",50]]},
  {id:17,category:"noodles",name:"Noodles with Chicken",description:"Stir-fried noodles with tender chicken",variants:[["GH₵40",40],["GH₵50",50]]},
  {id:18,category:"noodles",name:"Chicken Noodles",description:"A generous plate of chicken noodles",variants:[["GH₵40",40],["GH₵50",50]]},
  {id:19,category:"noodles",name:"Assorted Noodles",description:"Noodles loaded with assorted toppings",variants:[["GH₵40",40],["GH₵50",50]]},
  {id:20,category:"pizza",name:"Margarita",description:"Classic cheese and tomato pizza",variants:[["Small",80],["Medium",105],["Large",115]]},
  {id:21,category:"pizza",name:"All Seasoning",description:"Our fully loaded pizza",variants:[["Small",95],["Medium",125],["Large",150]]},
  {id:22,category:"pizza",name:"Beef",description:"Pizza topped with seasoned beef",variants:[["Small",85],["Medium",110],["Large",120]]},
  {id:23,category:"pizza",name:"Chicken",description:"Pizza topped with seasoned chicken",variants:[["Small",85],["Medium",110],["Large",120]]},
  {id:24,category:"pizza",name:"Beef and Chicken",description:"The best of both toppings",variants:[["Small",90],["Medium",115],["Large",125]]},
  {id:25,category:"pizza",name:"Beef and Sausage",description:"Beef and sausage with melted cheese",variants:[["Small",90],["Medium",115],["Large",125]]},
  {id:26,category:"pizza",name:"Vegetables",description:"Fresh vegetables and cheese",variants:[["Small",80],["Medium",105],["Large",115]]},
  {id:27,category:"pizza",name:"Mister Gentle Special",description:"Our signature loaded special pizza",variants:[["Small",100],["Medium",130],["Large",160]]}
]};
const menuGrid = document.querySelector("#product-grid");
const renderMenu = (category, query = "") => {
  const term = query.trim().toLowerCase();
  menuGrid.innerHTML = window.MisterGentleMenu.products.filter(p => (category === "all" || p.category === category) && (!term || `${p.name} ${p.description} ${p.category}`.toLowerCase().includes(term))).map(p => {
    const price = p.variants ? p.variants[0][1] : p.price;
    const options = p.variants ? `<div class="pizza-sizes"><span class="variant-label">${p.category === "pizza" ? "Pizza size" : "Serving"}</span>${p.variants.map((v, i) => `<button class="${i === 0 ? "active" : ""}" data-size="${v[0]}" data-price="${v[1]}">${v[0]}<small>${p.category === "pizza" ? `GH₵${v[1]}.00` : ""}</small></button>`).join("")}</div>` : "";
    const choices = p.choices ? `<div class="choice-options"><span class="variant-label">Chicken style</span>${p.choices.map((c, i) => `<button class="${i === 0 ? "active" : ""}" data-choice="${c}">${c}</button>`).join("")}</div>` : "";
    return `<article class="product-card"><div class="product-image"><div class="menu-placeholder"><span>MG</span><small>Photo coming soon</small></div></div><div class="product-info"><h3>${p.name}</h3><p>${p.description}</p>${options}${choices}<div class="product-bottom"><span class="price">GH₵${price}.00</span><button class="add-btn" data-add="${p.id}" data-selected-price="${price}" aria-label="Add ${p.name} to your basket" title="Add to basket">+</button></div></div></article>`;
  }).join("") || `<div class="no-results"><strong>No meals found</strong><span>Try another food name or browse all menu.</span></div>`;
};
document.querySelector("#category-tabs").addEventListener("click", event => { if (event.target.tagName !== "BUTTON") return; document.querySelectorAll("#category-tabs button").forEach(button => button.classList.remove("active")); event.target.classList.add("active"); renderMenu(event.target.dataset.category, document.querySelector("#menu-search").value); });
document.querySelector("#menu-search").addEventListener("input", event => renderMenu(document.querySelector("#category-tabs button.active").dataset.category, event.target.value));
document.querySelector("#clear-search").addEventListener("click", () => { const input = document.querySelector("#menu-search"); input.value = ""; renderMenu(document.querySelector("#category-tabs button.active").dataset.category); input.focus(); });
document.addEventListener("click", event => {
  const size = event.target.closest("[data-size]");
  if (size) {
    const card = size.closest(".product-card");
    card.querySelectorAll("[data-size]").forEach(button => button.classList.remove("active"));
    size.classList.add("active");
    card.querySelector(".price").textContent = `GH₵${size.dataset.price}.00`;
    card.querySelector("[data-add]").dataset.selectedPrice = size.dataset.price;
  }
  const choice = event.target.closest("[data-choice]");
  if (choice) {
    const card = choice.closest(".product-card");
    card.querySelectorAll("[data-choice]").forEach(button => button.classList.remove("active"));
    choice.classList.add("active");
  }
});
renderMenu("all");
