const express = require("express");
const router = express.Router();

const db = require("../../database/database");

// ========================================
// HELPER
// ========================================

function getProductWithVariants(productId) {
    const product = db
        .prepare(`
            SELECT
                p.*,
                c.name AS category_name
            FROM products p
            LEFT JOIN categories c
                ON p.category_id = c.id
            WHERE p.id = ?
        `)
        .get(productId);

    if (!product) {
        return null;
    }

    const variants = db
        .prepare(`
            SELECT
                id,
                product_id,
                name,
                price,
                sort_order
            FROM product_variants
            WHERE product_id = ?
            ORDER BY sort_order ASC, id ASC
        `)
        .all(productId);

    return {
        ...product,
        variants
    };
}

// ========================================
// GET ALL PRODUCTS
// ========================================

router.get("/", (req, res) => {
    try {
        const products = db
            .prepare(`
                SELECT
                    p.*,
                    c.name AS category_name
                FROM products p
                LEFT JOIN categories c
                    ON p.category_id = c.id
                ORDER BY p.id ASC
            `)
            .all();

        const productsWithVariants = products.map(product => {
            const variants = db
                .prepare(`
                    SELECT
                        id,
                        product_id,
                        name,
                        price,
                        sort_order
                    FROM product_variants
                    WHERE product_id = ?
                    ORDER BY sort_order ASC, id ASC
                `)
                .all(product.id);

            return {
                ...product,
                variants
            };
        });

        res.json({
            success: true,
            count: productsWithVariants.length,
            products: productsWithVariants
        });

    } catch (error) {
        console.error("Get products error:", error);

        res.status(500).json({
            success: false,
            message: "Failed to get products."
        });
    }
});

// ========================================
// GET PRODUCTS BY CATEGORY
// ========================================

router.get("/category/:categoryId", (req, res) => {
    try {
        const categoryId = Number(req.params.categoryId);

        if (!Number.isInteger(categoryId)) {
            return res.status(400).json({
                success: false,
                message: "Invalid category ID."
            });
        }

        const products = db
            .prepare(`
                SELECT
                    p.*,
                    c.name AS category_name
                FROM products p
                LEFT JOIN categories c
                    ON p.category_id = c.id
                WHERE p.category_id = ?
                ORDER BY p.id ASC
            `)
            .all(categoryId);

        const productsWithVariants = products.map(product => {
            const variants = db
                .prepare(`
                    SELECT
                        id,
                        product_id,
                        name,
                        price,
                        sort_order
                    FROM product_variants
                    WHERE product_id = ?
                    ORDER BY sort_order ASC, id ASC
                `)
                .all(product.id);

            return {
                ...product,
                variants
            };
        });

        res.json({
            success: true,
            count: productsWithVariants.length,
            products: productsWithVariants
        });

    } catch (error) {
        console.error("Get products by category error:", error);

        res.status(500).json({
            success: false,
            message: "Failed to get products by category."
        });
    }
});

// ========================================
// GET SINGLE PRODUCT
// ========================================

router.get("/:id", (req, res) => {
    try {
        const productId = Number(req.params.id);

        if (!Number.isInteger(productId)) {
            return res.status(400).json({
                success: false,
                message: "Invalid product ID."
            });
        }

        const product = getProductWithVariants(productId);

        if (!product) {
            return res.status(404).json({
                success: false,
                message: "Product not found."
            });
        }

        res.json({
            success: true,
            product
        });

    } catch (error) {
        console.error("Get single product error:", error);

        res.status(500).json({
            success: false,
            message: "Failed to get product."
        });
    }
});

// ========================================
// CREATE PRODUCT
// ========================================

router.post("/", (req, res) => {
    try {
        const {
            category_id,
            name,
            description,
            price,
            image,
            is_available
        } = req.body;

        if (!category_id || !name || price === undefined) {
            return res.status(400).json({
                success: false,
                message: "Category, product name and price are required."
            });
        }

        const result = db
            .prepare(`
                INSERT INTO products
                (
                    category_id,
                    name,
                    description,
                    price,
                    image,
                    is_available
                )
                VALUES (?, ?, ?, ?, ?, ?)
            `)
            .run(
                Number(category_id),
                name,
                description || "",
                Number(price),
                image || "",
                is_available === undefined ? 1 : Number(is_available)
            );

        const product = getProductWithVariants(result.lastInsertRowid);

        res.status(201).json({
            success: true,
            message: "Product created successfully.",
            product
        });

    } catch (error) {
        console.error("Create product error:", error);

        res.status(500).json({
            success: false,
            message: "Failed to create product."
        });
    }
});

// ========================================
// UPDATE PRODUCT
// ========================================

router.put("/:id", (req, res) => {
    try {
        const productId = Number(req.params.id);

        if (!Number.isInteger(productId)) {
            return res.status(400).json({
                success: false,
                message: "Invalid product ID."
            });
        }

        const existingProduct = db
            .prepare(`
                SELECT *
                FROM products
                WHERE id = ?
            `)
            .get(productId);

        if (!existingProduct) {
            return res.status(404).json({
                success: false,
                message: "Product not found."
            });
        }

        const {
            category_id,
            name,
            description,
            price,
            image,
            is_available
        } = req.body;

        db.prepare(`
            UPDATE products
            SET
                category_id = ?,
                name = ?,
                description = ?,
                price = ?,
                image = ?,
                is_available = ?
            WHERE id = ?
        `).run(
            category_id !== undefined
                ? Number(category_id)
                : existingProduct.category_id,

            name !== undefined
                ? name
                : existingProduct.name,

            description !== undefined
                ? description
                : existingProduct.description,

            price !== undefined
                ? Number(price)
                : existingProduct.price,

            image !== undefined
                ? image
                : existingProduct.image,

            is_available !== undefined
                ? Number(is_available)
                : existingProduct.is_available,

            productId
        );

        const product = getProductWithVariants(productId);

        res.json({
            success: true,
            message: "Product updated successfully.",
            product
        });

    } catch (error) {
        console.error("Update product error:", error);

        res.status(500).json({
            success: false,
            message: "Failed to update product."
        });
    }
});

// ========================================
// DELETE PRODUCT
// ========================================

router.delete("/:id", (req, res) => {
    try {
        const productId = Number(req.params.id);

        if (!Number.isInteger(productId)) {
            return res.status(400).json({
                success: false,
                message: "Invalid product ID."
            });
        }

        const existingProduct = db
            .prepare(`
                SELECT id
                FROM products
                WHERE id = ?
            `)
            .get(productId);

        if (!existingProduct) {
            return res.status(404).json({
                success: false,
                message: "Product not found."
            });
        }

        db.prepare(`
            DELETE FROM product_variants
            WHERE product_id = ?
        `).run(productId);

        db.prepare(`
            DELETE FROM products
            WHERE id = ?
        `).run(productId);

        res.json({
            success: true,
            message: "Product deleted successfully."
        });

    } catch (error) {
        console.error("Delete product error:", error);

        res.status(500).json({
            success: false,
            message: "Failed to delete product."
        });
    }
});

// ========================================
// CREATE PRODUCT VARIANT
// ========================================

router.post("/:id/variants", (req, res) => {
    try {
        const productId = Number(req.params.id);

        if (!Number.isInteger(productId)) {
            return res.status(400).json({
                success: false,
                message: "Invalid product ID."
            });
        }

        const product = db
            .prepare(`
                SELECT id
                FROM products
                WHERE id = ?
            `)
            .get(productId);

        if (!product) {
            return res.status(404).json({
                success: false,
                message: "Product not found."
            });
        }

        const {
            name,
            price,
            sort_order
        } = req.body;

        if (!name || price === undefined) {
            return res.status(400).json({
                success: false,
                message: "Variant name and price are required."
            });
        }

        const result = db
            .prepare(`
                INSERT INTO product_variants
                (
                    product_id,
                    name,
                    price,
                    sort_order
                )
                VALUES (?, ?, ?, ?)
            `)
            .run(
                productId,
                name,
                Number(price),
                sort_order === undefined ? 0 : Number(sort_order)
            );

        const variant = db
            .prepare(`
                SELECT
                    id,
                    product_id,
                    name,
                    price,
                    sort_order
                FROM product_variants
                WHERE id = ?
            `)
            .get(result.lastInsertRowid);

        res.status(201).json({
            success: true,
            message: "Product variant created successfully.",
            variant
        });

    } catch (error) {
        console.error("Create product variant error:", error);

        res.status(500).json({
            success: false,
            message: "Failed to create product variant."
        });
    }
});

// ========================================
// UPDATE PRODUCT VARIANT
// ========================================

router.put("/:id/variants/:variantId", (req, res) => {
    try {
        const productId = Number(req.params.id);
        const variantId = Number(req.params.variantId);

        if (!Number.isInteger(productId) || !Number.isInteger(variantId)) {
            return res.status(400).json({
                success: false,
                message: "Invalid product or variant ID."
            });
        }

        const variant = db
            .prepare(`
                SELECT *
                FROM product_variants
                WHERE id = ?
                AND product_id = ?
            `)
            .get(variantId, productId);

        if (!variant) {
            return res.status(404).json({
                success: false,
                message: "Product variant not found."
            });
        }

        const {
            name,
            price,
            sort_order
        } = req.body;

        db.prepare(`
            UPDATE product_variants
            SET
                name = ?,
                price = ?,
                sort_order = ?
            WHERE id = ?
            AND product_id = ?
        `).run(
            name !== undefined ? name : variant.name,
            price !== undefined ? Number(price) : variant.price,
            sort_order !== undefined
                ? Number(sort_order)
                : variant.sort_order,
            variantId,
            productId
        );

        const updatedVariant = db
            .prepare(`
                SELECT
                    id,
                    product_id,
                    name,
                    price,
                    sort_order
                FROM product_variants
                WHERE id = ?
            `)
            .get(variantId);

        res.json({
            success: true,
            message: "Product variant updated successfully.",
            variant: updatedVariant
        });

    } catch (error) {
        console.error("Update product variant error:", error);

        res.status(500).json({
            success: false,
            message: "Failed to update product variant."
        });
    }
});

// ========================================
// DELETE PRODUCT VARIANT
// ========================================

router.delete("/:id/variants/:variantId", (req, res) => {
    try {
        const productId = Number(req.params.id);
        const variantId = Number(req.params.variantId);

        if (!Number.isInteger(productId) || !Number.isInteger(variantId)) {
            return res.status(400).json({
                success: false,
                message: "Invalid product or variant ID."
            });
        }

        const variant = db
            .prepare(`
                SELECT id
                FROM product_variants
                WHERE id = ?
                AND product_id = ?
            `)
            .get(variantId, productId);

        if (!variant) {
            return res.status(404).json({
                success: false,
                message: "Product variant not found."
            });
        }

        db.prepare(`
            DELETE FROM product_variants
            WHERE id = ?
            AND product_id = ?
        `).run(variantId, productId);

        res.json({
            success: true,
            message: "Product variant deleted successfully."
        });

    } catch (error) {
        console.error("Delete product variant error:", error);

        res.status(500).json({
            success: false,
            message: "Failed to delete product variant."
        });
    }
});

// ========================================
// EXPORT ROUTER
// ========================================

module.exports = router;