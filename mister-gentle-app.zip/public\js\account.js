const authCard = document.querySelector("#auth-card");
const profileCard = document.querySelector("#profile-card");
const message = document.querySelector("#form-message");
const setMessage = text => { message.textContent = text; };
function showProfile(user) {
    authCard.hidden = true;
    profileCard.hidden = false;
    document.querySelector("#profile-name").textContent = `Hello, ${user.first_name}.`;
}
async function checkSession() {
    const response = await fetch("/api/users/me");
    const data = await response.json();
    if (data.user) showProfile(data.user);
}
document.querySelectorAll("[data-auth-tab]").forEach(tab => tab.addEventListener("click", () => {
    const register = tab.dataset.authTab === "register";
    document.querySelectorAll("[data-auth-tab]").forEach(item => item.classList.toggle("active", item === tab));
    document.querySelector("#login-form").hidden = register;
    document.querySelector("#register-form").hidden = !register;
    document.querySelector("#auth-title").textContent = register ? "Make it official." : "Good to see you.";
    document.querySelector("#auth-description").textContent = register ? "Create an account and make every order feel effortless." : "Log in to track orders and save your favourites.";
    document.querySelector(".account-heading .eyebrow").textContent = register ? "JOIN THE GENTLE CLUB" : "WELCOME BACK";
    setMessage("");
}));
async function submitAuth(event, endpoint) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const body = Object.fromEntries(form.entries());
    try {
        const response = await fetch(`/api/users/${endpoint}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
        const data = await response.json();
        if (!response.ok) return setMessage(data.message || "Something went wrong.");
        showProfile(data.user);
    } catch (error) {
        setMessage("We could not reach the server. Please try again.");
    }
}
document.querySelector("#login-form").addEventListener("submit", event => submitAuth(event, "login"));
document.querySelector("#register-form").addEventListener("submit", event => submitAuth(event, "register"));
document.querySelector("#logout-btn").addEventListener("click", async () => { await fetch("/api/auth/logout", { method: "POST" }); window.location.reload(); });
checkSession();
