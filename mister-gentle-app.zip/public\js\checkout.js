const checkoutCart = JSON.parse(localStorage.getItem("gentle-cart") || "[]");
if (!checkoutCart.length) window.location.replace("/cart.html");
const checkoutType = document.querySelector('#checkout-form select[name="order_type"]');
const addressField = document.querySelector('#checkout-form textarea[name="address"]');
const paymentMethod = document.querySelector("#payment-method");
function updateAddressRequirement() {
    const delivery = checkoutType.value === "delivery";
    addressField.required = delivery;
    addressField.closest("label").style.display = delivery ? "block" : "none";
    if (!delivery) addressField.value = "";
    const cashOption = paymentMethod.querySelector("[data-cash-option]");
    cashOption.textContent = delivery ? "Cash on delivery" : "Cash on pickup";
    cashOption.value = delivery ? "cash_delivery" : "cash_pickup";
    if (paymentMethod.value === "cash_delivery" || paymentMethod.value === "cash_pickup") paymentMethod.value = delivery ? "cash_delivery" : "cash_pickup";
}
checkoutType.addEventListener("change", updateAddressRequirement);
const savedOrderType = localStorage.getItem("gentle-order-type");
if (savedOrderType === "pickup" || savedOrderType === "delivery") checkoutType.value = savedOrderType;
updateAddressRequirement();
document.querySelector("#checkout-form").addEventListener("submit", async event => {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    const response = await fetch("/api/orders", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ customer_name: data.get("name"), customer_phone: data.get("phone"), delivery_address: data.get("address"), order_type: data.get("order_type"), payment_method: data.get("payment_method"), items: checkoutCart }) });
    const result = await response.json();
    if (!response.ok) return alert(result.message || "Unable to place order.");
    form.style.display = "none";
    localStorage.setItem("gentle-last-order", result.order_number);
    document.querySelector("#success-copy").textContent = `Order ${result.order_number} is waiting for confirmation.`;
    document.querySelector("#track-order-link").href = `/order-status.html?order=${encodeURIComponent(result.order_number)}`;
    document.querySelector("#success-message").classList.add("show");
    localStorage.removeItem("gentle-cart");
});
