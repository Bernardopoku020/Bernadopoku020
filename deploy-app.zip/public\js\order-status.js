const form = document.querySelector("#status-form");
const input = document.querySelector("#order-number");
const message = document.querySelector("#status-message");
const result = document.querySelector("#status-result");
const notification = document.querySelector("#status-notification");
const steps = ["pending", "accepted", "preparing", "ready", "completed"];
const labels = { pending: "Order received", accepted: "Accepted", rejected: "Rejected", preparing: "Preparing", ready: "Ready for collection / delivery", completed: "Completed" };
let timer;
let previousStatus;
function notifyStatusChange(order) {
    if (!previousStatus || previousStatus === order.status) {
        previousStatus = order.status;
        return;
    }
    const statusText = labels[order.status] || order.status;
    notification.textContent = `Order update: your order is now ${statusText}.`;
    notification.hidden = false;
    if ("Notification" in window && Notification.permission === "granted") {
        new Notification("Mister Gentle order update", {
            body: `Your order ${order.order_number} is now ${statusText}.`,
            tag: order.order_number
        });
    }
    previousStatus = order.status;
}
async function loadStatus(number) {
    try {
        const response = await fetch(`/api/orders/${encodeURIComponent(number)}`);
        const data = await response.json();
        if (!response.ok) throw new Error(data.message || "Order not found.");
        const order = data.order;
        notifyStatusChange(order);
        result.hidden = false;
        result.innerHTML = `<div class="status-summary"><strong>${order.order_number}</strong><span>${order.order_type === "pickup" ? "Pickup" : "Delivery"} · GH₵${Number(order.total).toFixed(2)}</span></div><div class="status-pill status-${order.status}">${labels[order.status] || order.status}</div>${order.status === "rejected" ? "<p class=\"rejected-copy\">We’re sorry, this order was rejected. Please contact Mister Gentle for help.</p>" : `<div class="status-steps">${steps.map((step, index) => `<div class="${steps.indexOf(order.status) >= index ? "done" : ""}"><span>${steps.indexOf(order.status) >= index ? "✓" : index + 1}</span><small>${labels[step]}</small></div>`).join("")}</div>`}<div class="status-items">${order.items.map(item => `<p>${item.quantity} × ${item.product_name}</p>`).join("")}</div>`;
        message.textContent = `Updated ${new Date().toLocaleTimeString()}`;
    } catch (error) {
        result.hidden = true;
        message.textContent = error.message;
    }
}
const queryOrder = new URLSearchParams(location.search).get("order") || localStorage.getItem("gentle-last-order");
if (queryOrder) { input.value = queryOrder; loadStatus(queryOrder); timer = setInterval(() => loadStatus(queryOrder), 10000); }
form.addEventListener("submit", async event => { event.preventDefault(); const number = input.value.trim().toUpperCase(); if (!number) return; localStorage.setItem("gentle-last-order", number); clearInterval(timer); previousStatus = undefined; if ("Notification" in window && Notification.permission === "default") await Notification.requestPermission(); loadStatus(number); timer = setInterval(() => loadStatus(number), 10000); });
