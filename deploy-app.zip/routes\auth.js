const express = require("express");
const bcrypt = require("bcryptjs");
const db = require("../database/database");
const router = express.Router();

function publicAdmin(admin) {
    return {
        id: admin.id,
        username: admin.username,
        full_name: admin.full_name,
        role: admin.role
    };
}

router.post("/register", async (req, res) => {
    const { username, full_name, password } = req.body;
    if (!username || !full_name || !password) return res.status(400).json({ success: false, message: "Name, username and password are required." });
    if (password.length < 8) return res.status(400).json({ success: false, message: "Password must be at least 8 characters." });
    try {
        if (db.prepare("SELECT id FROM admins WHERE username = ?").get(username.trim())) {
            return res.status(409).json({ success: false, message: "That staff username is already in use." });
        }
        const hash = await bcrypt.hash(password, 12);
        const result = db.prepare("INSERT INTO admins (username, password, full_name, role) VALUES (?, ?, ?, 'worker')").run(username.trim(), hash, full_name.trim());
        const admin = db.prepare("SELECT * FROM admins WHERE id = ?").get(result.lastInsertRowid);
        req.session.admin = publicAdmin(admin);
        res.status(201).json({ success: true, user: req.session.admin });
    } catch (error) {
        console.error("Staff registration error:", error);
        res.status(500).json({ success: false, message: "Could not create the staff account." });
    }
});

router.get("/me", (req, res) => {
    res.json({ success: true, user: req.session.admin || null });
});

router.post("/login", async (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) return res.status(400).json({ success: false, message: "Username and password are required." });
    try {
        const admin = db.prepare("SELECT * FROM admins WHERE username = ?").get(username.trim());
        const valid = admin && await bcrypt.compare(password, admin.password);
        if (!valid) return res.status(401).json({ success: false, message: "Those login details are not correct." });
        req.session.admin = publicAdmin(admin);
        res.json({ success: true, user: req.session.admin });
    } catch (error) {
        console.error("Admin login error:", error);
        res.status(500).json({ success: false, message: "Could not log you in." });
    }
});

router.post("/logout", (req, res) => {
    req.session.destroy(error => {
        if (error) return res.status(500).json({ success: false, message: "Could not log out." });
        res.clearCookie("connect.sid");
        res.json({ success: true });
    });
});

module.exports = router;
