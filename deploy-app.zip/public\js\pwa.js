let deferredInstall;
function showInstallBanner() {
    if (localStorage.getItem("gentle-install-dismissed")) return;
    const banner = document.createElement("aside");
    banner.className = "install-banner";
    banner.innerHTML = `<strong>Install Mister Gentle</strong><span>Keep ordering on your phone like an app.</span><button id="install-app">Install app</button><button id="dismiss-install" aria-label="Dismiss">×</button>`;
    document.body.appendChild(banner);
    document.querySelector("#dismiss-install").onclick = () => { localStorage.setItem("gentle-install-dismissed", "1"); banner.remove(); };
    document.querySelector("#install-app").onclick = async () => {
        if (!deferredInstall) { alert("On iPhone: tap Share, then Add to Home Screen. On Android: use your browser menu and choose Install app."); return; }
        deferredInstall.prompt();
        await deferredInstall.userChoice;
        deferredInstall = null;
        banner.remove();
    };
}
if ("serviceWorker" in navigator) window.addEventListener("load", () => navigator.serviceWorker.register("/service-worker.js").catch(error => console.error("App install support unavailable:", error)));
window.addEventListener("beforeinstallprompt", event => { event.preventDefault(); deferredInstall = event; showInstallBanner(); });
window.addEventListener("load", () => { if (/iPhone|iPad|iPod|Android/i.test(navigator.userAgent)) setTimeout(showInstallBanner, 1200); });
