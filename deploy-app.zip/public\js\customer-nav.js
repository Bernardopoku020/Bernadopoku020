(() => {
    const path = window.location.pathname;
    const active = path === "/" ? "home" : path.includes("account") ? "rewards" : path.includes("order-status") ? "track" : path.includes("cart") ? "cart" : "menu";
    const nav = document.createElement("nav");
    nav.className = "customer-bottom-nav";
    nav.setAttribute("aria-label", "Customer navigation");
    nav.innerHTML = `
        <a class="${active === "home" ? "active" : ""}" href="/"><span class="nav-icon">⌂</span><span>Home</span></a>
        <a class="${active === "menu" ? "active" : ""}" href="/menu.html"><span class="nav-icon">🍽</span><span>Menu</span></a>
        <a class="${active === "rewards" ? "active" : ""}" href="/account.html#rewards"><span class="nav-icon">★</span><span>Rewards</span></a>
        <a class="${active === "track" ? "active" : ""}" href="/order-status.html"><span class="nav-icon">📍</span><span>Track</span></a>
        <a class="${active === "cart" ? "active" : ""}" href="/cart.html"><span class="nav-icon">▱ <b class="cart-nav-count">0</b></span><span>Cart</span></a>
    `;
    document.body.appendChild(nav);
    const count = nav.querySelector(".cart-nav-count");
    const updateCount = () => { count.textContent = JSON.parse(localStorage.getItem("gentle-cart") || "[]").reduce((sum, item) => sum + Number(item.qty || 0), 0); };
    updateCount();
    window.addEventListener("storage", updateCount);
})();
