const staffMessage = document.querySelector("#staff-message");
const staffRequest = async (event, endpoint) => {
    event.preventDefault();
    const body = Object.fromEntries(new FormData(event.currentTarget).entries());
    const response = await fetch(`/api/auth/${endpoint}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const data = await response.json();
    if (!response.ok) { staffMessage.textContent = data.message || "Unable to continue."; return; }
    window.location.href = "/admin/";
};
if (document.querySelector("#staff-login")) {
    document.querySelector("#staff-login").addEventListener("submit", event => staffRequest(event, "login"));
    document.querySelector("#staff-register").addEventListener("submit", event => staffRequest(event, "register"));
    document.querySelectorAll("[data-staff-tab]").forEach(tab => tab.addEventListener("click", () => {
        const register = tab.dataset.staffTab === "register";
        document.querySelectorAll("[data-staff-tab]").forEach(item => item.classList.toggle("active", item === tab));
        document.querySelector("#staff-login").hidden = register;
        document.querySelector("#staff-register").hidden = !register;
        document.querySelector("#staff-title").textContent = register ? "Join the team." : "Welcome back.";
        document.querySelector("#staff-description").textContent = register ? "Create your own secure staff account." : "Log in to receive and manage customer orders.";
        staffMessage.textContent = "";
    }));
}
if (document.querySelector("#staff-name")) {
    fetch("/api/auth/me").then(response => response.json()).then(data => { document.querySelector("#staff-name").textContent = data.user ? `Signed in as ${data.user.full_name}` : ""; });
    document.querySelector("#staff-logout").addEventListener("click", async () => { await fetch("/api/auth/logout", { method: "POST" }); window.location.href = "/admin/login.html"; });
}
const ordersList = document.querySelector("#orders-list");
let latestOrders = [];
function renderOrders(orders) {
    const filter = document.querySelector("#order-filter")?.value || "all";
    const visible = filter === "all" ? orders : orders.filter(order => order.status === filter);
    ordersList.innerHTML = visible.length ? visible.map(order => `<article class="order-card"><div class="order-card-head"><div><h3>${order.order_number}</h3><p class="order-meta">${order.customer_name} · ${order.customer_phone} · ${new Date(order.created_at).toLocaleString()}</p></div><select data-status="${order.order_number}" aria-label="Update order status" ${["completed", "rejected"].includes(order.status) ? "disabled" : ""}>${["pending","accepted","rejected","preparing","ready","completed"].map(status => `<option value="${status}" ${status === order.status ? "selected" : ""}>${status === "accepted" ? "Accepted" : status === "rejected" ? "Rejected" : status[0].toUpperCase() + status.slice(1)}</option>`).join("")}</select></div><div class="order-items">${order.items.map(item => `<div class="order-item"><span>${item.quantity} × ${item.product_name}</span><b>GH₵${Number(item.total_price).toFixed(2)}</b></div>`).join("")}</div><p class="order-address">${order.order_type === "pickup" ? "Pickup order" : `Deliver to: ${order.delivery_address || "Address not provided"}`} · Payment: ${order.payment_method}</p><div class="order-card-foot"><span>Subtotal GH₵${Number(order.subtotal).toFixed(2)} · Fee GH₵${Number(order.delivery_fee).toFixed(2)}</span><strong>GH₵${Number(order.total).toFixed(2)}</strong></div></article>`).join("") : `<p class="order-empty">No ${filter === "all" ? "" : filter + " "}orders found.</p>`;
}
async function loadOrders() {
    if (!ordersList) return;
    const response = await fetch("/api/orders");
    if (response.status === 401) { window.location.href = "/admin/login.html"; return; }
    const data = await response.json();
    if (!response.ok) { ordersList.innerHTML = `<p class="order-empty">${data.message || "Could not load orders."}</p>`; return; }
    const hadNewOrder = latestOrders.length && data.orders.some(order => !latestOrders.some(previous => previous.order_number === order.order_number));
    latestOrders = data.orders;
    renderOrders(latestOrders);
    if (hadNewOrder) { const badge = document.querySelector("#new-orders-badge"); if (badge) { badge.hidden = false; setTimeout(() => { badge.hidden = true; }, 5000); } }
    const updated = document.querySelector("#orders-updated");
    if (updated) updated.textContent = `Last checked ${new Date().toLocaleTimeString()}`;
}
if (ordersList) { document.querySelector("#refresh-orders").addEventListener("click", loadOrders); document.querySelector("#order-filter").addEventListener("change", () => renderOrders(latestOrders)); ordersList.addEventListener("change", async event => { if (!event.target.dataset.status) return; const response = await fetch(`/api/orders/${event.target.dataset.status}/status`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status: event.target.value }) }); if (!response.ok) { const data = await response.json(); alert(data.message || "Could not update order status."); } loadOrders(); }); loadOrders(); setInterval(loadOrders, 10000); }
const dashboardOrders = document.querySelector("#dashboard-orders");
if (dashboardOrders) {
    async function loadDashboard() {
        const response = await fetch("/api/orders");
        if (response.status === 401) { window.location.href = "/admin/login.html"; return; }
        const data = await response.json();
        if (!response.ok) { dashboardOrders.innerHTML = `<p class="order-empty">${data.message || "Could not load orders."}</p>`; return; }
        const today = new Date().toDateString();
        const todayOrders = data.orders.filter(order => new Date(order.created_at).toDateString() === today);
        document.querySelector("#metric-orders").textContent = todayOrders.length;
        document.querySelector("#metric-pending").textContent = todayOrders.filter(order => ["pending", "accepted"].includes(order.status)).length;
        const completedOrders = todayOrders.filter(order => order.status === "completed");
        document.querySelector("#metric-sales").textContent = `GH₵${completedOrders.reduce((sum, order) => sum + Number(order.total), 0).toFixed(2)}`;
        dashboardOrders.innerHTML = data.orders.slice(0, 5).map(order => `<a class="dashboard-order-row" href="/admin/orders.html"><strong>${order.order_number}</strong><span>${order.customer_name}</span><b class="status-text status-${order.status}">${order.status}</b><strong>GH₵${Number(order.total).toFixed(2)}</strong></a>`).join("") || `<p class="order-empty">No customer orders yet.</p>`;
        document.querySelector("#dashboard-updated").textContent = `Updated ${new Date().toLocaleTimeString()}`;
    }
    const customersList = document.querySelector("#customers-list");
    if (customersList) {
        async function loadCustomers() {
            const response = await fetch("/api/users/admin-list");
            if (response.status === 401) { window.location.href = "/admin/login.html"; return; }
            const data = await response.json();
            if (!response.ok) { customersList.innerHTML = `<p class="order-empty">${data.message || "Could not load customers."}</p>`; return; }
            customersList.innerHTML = data.customers.length ? data.customers.map(customer => `<article class="customer-card"><div><h3>${customer.first_name} ${customer.last_name}</h3><p>${customer.email || "No email"} · ${customer.phone}</p><small>Joined ${new Date(customer.created_at).toLocaleDateString()} · ${customer.order_count} order(s)</small></div><div class="customer-stats"><b>${customer.loyalty_points} pts</b><span>${customer.phone_verified && (!customer.email || customer.email_verified) ? "Verified" : "Verification pending"}</span></div></article>`).join("") : `<p class="order-empty">No customer accounts yet.</p>`;
            document.querySelector("#customers-updated").textContent = `Updated ${new Date().toLocaleTimeString()}`;
        }
        document.querySelector("#refresh-customers").addEventListener("click", loadCustomers);
        loadCustomers();
    }
    loadDashboard(); setInterval(loadDashboard, 10000);
}
