const express = require("express");
const db = require("../database/database");
const router = express.Router();

function requireAdmin(req, res, next) {
    if (!req.session.admin) return res.status(401).json({ success: false, message: "Staff login required." });
    next();
}

function requireCustomer(req, res, next) {
    if (!req.session.customer) return res.status(401).json({ success: false, message: "Please log in or create a customer account before placing an order.", code: "CUSTOMER_LOGIN_REQUIRED" });
    next();
}

function customerOwnsOrder(req, order) {
    return req.session.admin || (req.session.customer && order.customer_id === req.session.customer.id);
}

router.get("/", requireAdmin, (req, res) => {
    const orders = db.prepare(`
        SELECT id, order_number, order_type, status, payment_status, payment_method,
               subtotal, delivery_fee, total, customer_name, customer_phone,
               delivery_address, created_at
        FROM orders
        ORDER BY created_at DESC, id DESC
    `).all().map(order => ({
        ...order,
        items: db.prepare("SELECT product_name, quantity, unit_price, total_price FROM order_items WHERE order_id = ?").all(order.id)
    }));
    res.json({ success: true, orders });
});

router.get("/mine", requireCustomer, (req, res) => {
    const orders = db.prepare(`
        SELECT id, order_number, order_type, status, payment_method, total, created_at
        FROM orders
        WHERE customer_id = ?
        ORDER BY created_at DESC, id DESC
        LIMIT 20
    `).all(req.session.customer.id).map(order => ({
        ...order,
        items: db.prepare("SELECT product_name, quantity FROM order_items WHERE order_id = ?").all(order.id)
    }));
    res.json({ success: true, orders });
});

router.patch("/:orderNumber/status", requireAdmin, (req, res) => {
    const allowed = ["pending", "accepted", "rejected", "preparing", "ready", "completed"];
    if (!allowed.includes(req.body.status)) return res.status(400).json({ success: false, message: "Invalid order status." });
    const currentOrder = db.prepare("SELECT status FROM orders WHERE order_number = ?").get(req.params.orderNumber);
    if (!currentOrder) return res.status(404).json({ success: false, message: "Order not found." });
    if (["completed", "rejected"].includes(currentOrder.status) && req.body.status !== currentOrder.status) {
        return res.status(409).json({ success: false, message: `${currentOrder.status[0].toUpperCase() + currentOrder.status.slice(1)} orders cannot be changed.` });
    }
    const updateOrder = db.transaction(() => {
        const result = db.prepare("UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE order_number = ?").run(req.body.status, req.params.orderNumber);
        if (req.body.status === "completed") {
            const order = db.prepare("SELECT id, customer_id, total FROM orders WHERE order_number = ?").get(req.params.orderNumber);
            if (order && order.customer_id && !db.prepare("SELECT id FROM loyalty_points WHERE order_id = ? AND transaction_type = 'earned'").get(order.id)) {
                const points = Math.floor(Number(order.total));
                if (points > 0) {
                    db.prepare(`
                        INSERT INTO loyalty_points (customer_id, points, transaction_type, description, order_id)
                        VALUES (?, ?, 'earned', ?, ?)
                    `).run(order.customer_id, points, `Earned from order ${req.params.orderNumber}`, order.id);
                }
            }
        }
        return result;
    });
    const result = updateOrder();
    if (!result.changes) return res.status(404).json({ success: false, message: "Order not found." });
    res.json({ success: true });
});

router.post("/", requireCustomer, (req, res) => {
    const { customer_name, customer_phone, delivery_address, order_type, payment_method, items } = req.body;
    if (!customer_name || !customer_phone || !Array.isArray(items) || !items.length) {
        return res.status(400).json({ success: false, message: "Name, phone number and at least one item are required." });
    }
    if (items.some(item => !item.name || !Number.isFinite(Number(item.price)) || !Number.isInteger(Number(item.qty)) || Number(item.qty) < 1)) {
        return res.status(400).json({ success: false, message: "Each order item must have a valid name, price and quantity." });
    }
    try {
        const subtotal = items.reduce((sum, item) => sum + Number(item.price) * Number(item.qty), 0);
        const deliveryFee = order_type === "pickup" ? 0 : (subtotal >= 150 ? 0 : 15);
        const orderNumber = `MG-${Date.now().toString().slice(-6)}`;
        db.transaction(() => {
            const result = db.prepare(`
                INSERT INTO orders (order_number, customer_id, order_type, payment_method, subtotal, delivery_fee, total, customer_name, customer_phone, delivery_address)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `).run(orderNumber, req.session.customer ? req.session.customer.id : null, order_type || "delivery", payment_method || "cash", subtotal, deliveryFee, subtotal + deliveryFee, customer_name.trim(), customer_phone.trim(), delivery_address || null);
            const insertItem = db.prepare(`
                INSERT INTO order_items (order_id, product_id, product_name, quantity, unit_price, total_price)
                VALUES (?, ?, ?, ?, ?, ?)
            `);
            items.forEach(item => {
                const options = [item.selectedSize, item.selectedChoice].filter(Boolean).join(", ");
                const requestedProductId = item.originalId || (Number.isInteger(Number(item.id)) ? Number(item.id) : null);
                const productId = requestedProductId && db.prepare("SELECT id FROM products WHERE id = ?").get(requestedProductId)
                    ? requestedProductId
                    : null;
                insertItem.run(result.lastInsertRowid, productId, options ? `${item.name} (${options})` : item.name, Number(item.qty), Number(item.price), Number(item.price) * Number(item.qty));
            });
        })();
        res.status(201).json({ success: true, order_number: orderNumber, total: subtotal + deliveryFee });
    } catch (error) {
        console.error("Create order error:", error);
        res.status(500).json({ success: false, message: "We could not place your order. Please try again." });
    }
});

router.get("/:orderNumber", (req, res) => {
    const order = db.prepare("SELECT * FROM orders WHERE order_number = ?").get(req.params.orderNumber);
    if (!order) return res.status(404).json({ success: false, message: "Order not found." });
    if (!customerOwnsOrder(req, order)) return res.status(403).json({ success: false, message: "You can only view orders from your own account." });
    const items = db.prepare("SELECT * FROM order_items WHERE order_id = ?").all(order.id);
    res.json({ success: true, order: { ...order, items } });
});

module.exports = router;
