const gentleCart = JSON.parse(localStorage.getItem("gentle-cart") || "[]");
const gentleMoney = value => `GH₵${Number(value).toFixed(2)}`;
const checkoutLink = document.querySelector("#checkout-link");
fetch("/api/users/me").then(response => response.json()).then(data => {
    if (data.user && checkoutLink) {
        checkoutLink.href = "/checkout.html";
        checkoutLink.innerHTML = "Continue to checkout <span>↗</span>";
    }
});
let gentleToastTimer;
function showGentleToast(message) {
    const toast = document.querySelector("#toast");
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(gentleToastTimer);
    gentleToastTimer = setTimeout(() => toast.classList.remove("show"), 2200);
}
let orderType = localStorage.getItem("gentle-order-type") === "pickup" ? "pickup" : "delivery";
function saveGentleCart() { localStorage.setItem("gentle-cart", JSON.stringify(gentleCart)); localStorage.setItem("gentle-order-type", orderType); }
function renderGentleCart() {
    const count = document.querySelector("#cart-count");
    if (count) count.textContent = gentleCart.reduce((sum, item) => sum + item.qty, 0);
    const items = document.querySelector("#cart-items");
    if (!items) return;
    const empty = document.querySelector("#cart-empty");
    const footer = document.querySelector("#cart-footer");
    empty.style.display = gentleCart.length ? "none" : "block";
    footer.style.display = gentleCart.length ? "block" : "none";
    items.innerHTML = gentleCart.map(item => `<article class="cart-page-item"><div class="cart-item-copy"><h3>${item.name}</h3><small>${[item.selectedSize, item.selectedChoice].filter(Boolean).join(" · ")}</small><b>${gentleMoney(item.price)}</b></div><div class="cart-controls"><button data-minus="${item.id}" aria-label="Decrease ${item.name} quantity">−</button><strong>${item.qty}</strong><button data-plus="${item.id}" aria-label="Increase ${item.name} quantity">+</button><button class="remove-item" data-remove="${item.id}">Remove</button></div><strong class="line-total">${gentleMoney(item.price * item.qty)}</strong></article>`).join("");
    const subtotal = gentleCart.reduce((sum, item) => sum + item.price * item.qty, 0);
    const fee = orderType === "pickup" || subtotal >= 150 ? 0 : 15;
    const totalElement = document.querySelector("#cart-total");
    if (totalElement) totalElement.textContent = gentleMoney(subtotal);
    const feeElement = document.querySelector("#delivery-fee");
    if (feeElement) feeElement.textContent = fee ? gentleMoney(fee) : "FREE";
    const grandTotal = document.querySelector("#grand-total");
    if (grandTotal) grandTotal.textContent = gentleMoney(subtotal + fee);
    document.querySelectorAll("[data-order-type]").forEach(button => button.classList.toggle("active", button.dataset.orderType === orderType));
    const note = document.querySelector("#delivery-note");
    if (note) note.textContent = orderType === "pickup" ? "Collect from Mister Gentle — no delivery fee" : subtotal >= 150 ? "You qualify for free delivery" : "Free delivery on orders over GH₵150";
}
document.addEventListener("click", event => {
    const add = event.target.closest("[data-add]");
    if (add && window.MisterGentleMenu) {
        const product = window.MisterGentleMenu.products.find(item => item.id === Number(add.dataset.add));
        if (product) {
            const card = add.closest(".product-card");
            const selectedSize = card?.querySelector("[data-size].active")?.dataset.size || null;
            const selectedChoice = card?.querySelector("[data-choice].active")?.dataset.choice || null;
            const price = Number(add.dataset.selectedPrice || product.price || product.variants?.[0]?.[1]);
            const cartId = `${product.id}-${price}-${selectedSize || ""}-${selectedChoice || ""}`;
            const existing = gentleCart.find(item => String(item.id) === cartId);
            existing ? existing.qty++ : gentleCart.push({ ...product, id: cartId, originalId: product.id, price, selectedSize, selectedChoice, qty: 1 });
            saveGentleCart(); renderGentleCart(); showGentleToast(`${product.name} added to your basket`);
        }
    }
    const plus = event.target.closest("[data-plus]"), minus = event.target.closest("[data-minus]"), remove = event.target.closest("[data-remove]");
    const itemId = (plus || minus || remove)?.dataset[plus ? "plus" : minus ? "minus" : "remove"];
    if (itemId) { const item = gentleCart.find(entry => String(entry.id) === itemId); if (remove) item.qty = 0; else item.qty += plus ? 1 : -1; while (gentleCart.some(entry => entry.qty < 1)) gentleCart.splice(gentleCart.findIndex(entry => entry.qty < 1), 1); saveGentleCart(); renderGentleCart(); }
    const mode = event.target.closest("[data-order-type]");
    if (mode) { orderType = mode.dataset.orderType; saveGentleCart(); renderGentleCart(); }
});
renderGentleCart();
