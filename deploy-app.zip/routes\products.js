module.exports = require("../server/routes/productRoutes");
