module.exports = require("../server/routes/categoryRoutes");
