const authCard = document.querySelector("#auth-card");
const profileCard = document.querySelector("#profile-card");
const message = document.querySelector("#form-message");
const verificationForm = document.querySelector("#verification-form");
const nextPage = new URLSearchParams(window.location.search).get("next");
const setMessage = text => { message.textContent = text; };
async function showProfile(user) {
    authCard.hidden = true;
    profileCard.hidden = false;
    document.querySelector("#profile-name").textContent = `Hello, ${user.first_name}.`;
    const [loyaltyResponse, ordersResponse] = await Promise.all([fetch("/api/users/loyalty"), fetch("/api/orders/mine")]);
    const data = await loyaltyResponse.json();
    const ordersData = await ordersResponse.json();
    document.querySelector("#loyalty-points").textContent = `${data.points} points`;
    document.querySelector("#loyalty-history").innerHTML = data.history.length
        ? `<h3>Recent rewards activity</h3>${data.history.map(item => `<p><span>${item.description}</span><b>${item.points > 0 ? "+" : ""}${item.points}</b></p>`).join("")}`
        : "<p class=\"loyalty-empty\">Complete your first order to start earning rewards.</p>";
    document.querySelector("#account-orders-list").innerHTML = ordersData.orders.length
        ? ordersData.orders.map(order => `<a class="account-order" href="/order-status.html?order=${encodeURIComponent(order.order_number)}"><div><b>${order.order_number}</b><small>${order.items.reduce((sum, item) => sum + item.quantity, 0)} item(s) · ${new Date(order.created_at).toLocaleDateString()}</small></div><span class="status-text status-${order.status}">${order.status}</span><strong>GH₵${Number(order.total).toFixed(2)}</strong></a>`).join("")
        : "<p class=\"loyalty-empty\">Your completed orders will appear here.</p>";
}
function continueToRequestedPage() {
    if (nextPage && nextPage.startsWith("/") && !nextPage.startsWith("//")) window.location.replace(nextPage);
}
async function checkSession() {
    const response = await fetch("/api/users/me");
    const data = await response.json();
    if (data.user) {
        await showProfile(data.user);
        continueToRequestedPage();
    }
}
document.querySelectorAll("[data-auth-tab]").forEach(tab => tab.addEventListener("click", () => {
    const register = tab.dataset.authTab === "register";
    document.querySelectorAll("[data-auth-tab]").forEach(item => item.classList.toggle("active", item === tab));
    document.querySelector("#login-form").hidden = register;
    document.querySelector("#register-form").hidden = !register;
    document.querySelector("#auth-title").textContent = register ? "Make it official." : "Good to see you.";
    document.querySelector("#auth-description").textContent = register ? "Create an account and make every order feel effortless." : "Log in to track orders and save your favourites.";
    document.querySelector(".account-heading .eyebrow").textContent = register ? "JOIN THE GENTLE CLUB" : "WELCOME BACK";
    setMessage("");
}));
async function submitAuth(event, endpoint) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const body = Object.fromEntries(form.entries());
    try {
        const response = await fetch(`/api/users/${endpoint}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
        const data = await response.json();
        if (!response.ok && !data.verificationRequired) return setMessage(data.message || "Something went wrong.");
        if (data.verificationRequired) { verificationForm.hidden = false; document.querySelectorAll(".auth-form").forEach(form => { if (form !== verificationForm) form.hidden = true; }); return setMessage(`${data.message} Enter the code printed by the development server.`); }
        await showProfile(data.user);
        continueToRequestedPage();
    } catch (error) {
        setMessage("We could not reach the server. Please try again.");
    }
}
verificationForm.addEventListener("submit", async event => { event.preventDefault(); const body = Object.fromEntries(new FormData(event.currentTarget)); const response = await fetch("/api/users/verify", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }); const data = await response.json(); if (!response.ok) return setMessage(data.message); if (data.verified) { await showProfile(data.user); continueToRequestedPage(); } else setMessage("Phone verified. Now verify your email."); });
document.querySelector("#forgot-password").addEventListener("click", async () => { const identifier = window.prompt("Enter your email or phone number"); if (!identifier) return; const response = await fetch("/api/users/forgot-password", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ identifier }) }); const data = await response.json(); document.querySelectorAll(".auth-form").forEach(form => { form.hidden = form.id !== "reset-form"; }); setMessage(`${data.message} Enter the code printed by the development server.`); });
document.querySelector("#reset-form").addEventListener("submit", async event => { event.preventDefault(); const body = Object.fromEntries(new FormData(event.currentTarget)); const response = await fetch("/api/users/reset-password", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }); const data = await response.json(); if (!response.ok) return setMessage(data.message); document.querySelectorAll(".auth-form").forEach(form => { form.hidden = form.id !== "login-form"; }); setMessage(data.message); });
document.querySelector("#login-form").addEventListener("submit", event => submitAuth(event, "login"));
document.querySelector("#register-form").addEventListener("submit", event => submitAuth(event, "register"));
document.querySelector("#logout-btn").addEventListener("click", async () => { await fetch("/api/auth/logout", { method: "POST" }); window.location.reload(); });
checkSession();
